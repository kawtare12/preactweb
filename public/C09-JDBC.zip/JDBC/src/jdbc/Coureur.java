package jdbc;

public class Coureur {
	
	private int numDossart;
	private String nom;
	private String codeEquipe;
	private String codePays;

	public int getNumDossart() {
		return numDossart;
	}

	public void setNumDossart(int numDossart) {
		this.numDossart = numDossart;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getCodeEquipe() {
		return codeEquipe;
	}

	public void setCodeEquipe(String codeEquipe) {
		this.codeEquipe = codeEquipe;
	}

	public String getCodePays() {
		return codePays;
	}

	public void setCodePays(String codePays) {
		this.codePays = codePays;
	}

	public Coureur(int numDossart, String nom, String codeEquipe, String codePays) {
		this.numDossart = numDossart;
		this.nom = nom;
		this.codeEquipe = codeEquipe;
		this.codePays = codePays;
	}

}
