package jdbc;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class TourDeFrance {
	
	private Connection myConn;
	
	public TourDeFrance() throws Exception {
		
		// get db properties
		Properties props = new Properties();
		props.load(new FileInputStream("config.properties"));
		
		String user = props.getProperty("user");
		String password = props.getProperty("password");
		String dburl = props.getProperty("dburl");
		
		// connect to database
		myConn = DriverManager.getConnection(dburl, user, password);
		
		System.out.println("DB connection successful to: " + dburl);
	}
	
	
	public Connection getMyConn() {
		return myConn;
	}


	public String getCoureurName(int numDossart) throws SQLException {
		String nom = "";

		Statement myStmt = null;
		ResultSet myRs = null;

		try {
			// statement					
			myStmt = myConn.createStatement();
			String myQuery = "select nom from coureur where num_dossart = "+numDossart;
			
			// execute the query
			myRs = myStmt.executeQuery(myQuery);
			
			// get the result
			if(myRs.next())
				nom = myRs.getString("nom");
			
		}catch(SQLException e){
			System.out.println("Exception dans Select !"+e.getMessage());
		}finally {
			myRs.close();
			myStmt.close();
		}
		
		return nom;
	}
	
	public void addCoureur(Coureur c) throws SQLException {
		PreparedStatement myStmt = null;
		try {
		/*
			// statement
			 myStmt = myConn.createStatement();
			String myQuery = "insert into coureur (num_dossart, nom, code_equipe, code_pays)"
							+ "values ("+c.getNumDossart()+",\""+c.getNom()+"\",\""+c.getCodeEquipe()+"\",\""+c.getCodePays()+"\")";
			
			
			// execute the query
			myStmt.executeUpdate(myQuery); 
		*/
			
			// prepare statement
			myStmt = myConn.prepareStatement("insert into coureur (num_dossart, nom, code_equipe, code_pays) values (?,?,?,?)");
			
			// set params
			myStmt.setInt(1, c.getNumDossart());
			myStmt.setString(2, c.getNom());
			myStmt.setString(3, c.getCodeEquipe());
			myStmt.setString(4, c.getCodePays());
			
			// execute the query
			myStmt.executeUpdate();	
			
		}catch(SQLException e){
			System.out.println("Exception dans Insert :"+e.getMessage());
		}finally {
			myStmt.close();
		}
	}

	public static void main(String args[]){
		TourDeFrance tourDeFrance = null;
		try {
			tourDeFrance = new TourDeFrance();
			
			System.out.println("*************** Test du select *****************");
			System.out.println(tourDeFrance.getCoureurName(4));
			
			System.out.println("*************** Test du Insert *****************");
			Coureur c = new Coureur(10, "POO Java", "TMT", "ITA");
			tourDeFrance.addCoureur(c);
			System.out.println(tourDeFrance.getCoureurName(10));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
