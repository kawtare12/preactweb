drop table IF EXISTS temps;
drop table IF EXISTS etape;
drop table IF EXISTS coureur;
drop table IF EXISTS equipe;
drop table IF EXISTS pays;


create table equipe(
  code varchar(3),
  nom varchar(40),
  directeur varchar(40),
  constraint pk_eq primary key(code)
);

create table pays(
  code varchar(3),
  nom varchar(40),
 constraint pk_pa primary key(code)
);

create table coureur(
  num_dossart smallint,
  nom varchar(40),
  code_equipe varchar(3),
  code_pays varchar(3),
  constraint pk_co primary key(num_dossart),
  constraint fk_coce foreign key(code_equipe) references equipe(code),
  constraint fk_cocp foreign key(code_pays) references pays(code)
);


create table etape(
  num smallint,
  date_etape date,
  kms smallint,
  ville_depart varchar(20),
  ville_arrivee varchar(20),
  constraint pk_et primary key(num)
);

create table temps(
  num_dossart smallint,
  num_etape smallint,
  temps_realise time,
  constraint pk_tps primary key(num_dossart,num_etape),
  constraint fk_tmpnd foreign key(num_dossart) references coureur(num_dossart),
  constraint fk_tmpsne foreign key(num_etape) references etape(num)
);

insert into equipe values('TMT','T-MOBILE TEAM','Mario Kummer');
insert into equipe values('BLB','Brioche la Boulangere','Jean-Rene Bernaudeau');
insert into equipe values('USP','US Postal Service', 'Berry Floor' );

insert into pays values('FRA','France');
insert into pays values('EU', 'Etats Unis');
insert into pays values('CAN', 'Canada');
insert into pays values('ESP', 'Espagne');
insert into pays values('ALL','Allemagne');
insert into pays values('ITA', 'Italie');

insert into coureur values(1,'HIEKMANN Torsten','TMT','ALL');
insert into coureur values(2,'GUERINI Giuseppe','TMT','ITA');
insert into coureur values(3,'REICHL Dirk', 'TMT','ALL');
insert into coureur values(4,'CHAVANEL Sylvain','BLB','FRA');
insert into coureur values(5,'ROUS Didier','BLB','FRA');
insert into coureur values(6,'YUS QUEREJETA Unai','BLB','ESP');
insert into coureur values(7,'ARMSTRONG Lance','USP','EU');
insert into coureur values(8,'McCARTHY Patrick','USP','EU');
insert into coureur values(9,'BARRY Michael','USP','CAN');

insert into etape values(1,'2003-07-03',190,'Amiens','Chartres');
insert into etape values(2,'2003-07-04',205,'Chartres','Angers');

insert into temps values(1,1,'1:35:45');
insert into temps values(2,1,'1:54:23');
insert into temps values(3,1,'1:30:22');
insert into temps values(4,1,'1:23:34');
insert into temps values(5,1,'1:54:55');
insert into temps values(6,1,'1:46:44');
insert into temps values(7,1,'1:44:20');
insert into temps values(8,1,'1:34:23');
insert into temps values(9,1,'1:10:22');
insert into temps values(1,2,'1:50:23');
insert into temps values(2,2,'2:00:10');
insert into temps values(3,2,'1:45:34');
insert into temps values(4,2,'1:56:23');
insert into temps values(5,2,'1:55:20');
insert into temps values(6,2,'1:58:30');
insert into temps values(7,2,'1:59:34');
insert into temps values(8,2,'1:56:20');
insert into temps values(9,2,'2:10:34');
